txd = engineLoadTXD("market.txd", 1853 )
engineImportTXD(txd, 1853)
dff = engineLoadDFF("market.dff", 1853 )
engineReplaceModel(dff, 1853)
col = engineLoadCOL ( "market.col" )
engineReplaceCOL ( col, 1853 )
engineSetModelLODDistance(1853, 6000) 
 


--ID do objeto e a distância que ele irá carregar - distancia está como 500
----[CREDITOS]----

--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
txd = engineLoadTXD("turbus.txd", 1189 )
engineImportTXD(txd, 1189)
dff = engineLoadDFF("turbus.dff", 1189 )
engineReplaceModel(dff, 1189)
col = engineLoadCOL ( "turbus.col" )
engineReplaceCOL ( col, 1189 )
engineSetModelLODDistance(1189, 6000) 
engineSetModelLODDistance(1649, 6000) 


--ID do objeto e a distância que ele irá carregar - distancia está como 500
----[CREDITOS]----

--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
--@AlvesMTA#5709
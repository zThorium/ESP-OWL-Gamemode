-- FILE: 	mapEditorScriptingExtension_c.lua
-- PURPOSE:	Prevent the map editor feature set being limited by what MTA can load from a map file by adding a script file to maps
-- VERSION:	RemoveWorldObjects (v1) AutoLOD (v1) BreakableObjects (v1)


function requestLODsClient()
	triggerServerEvent("requestLODsClient", resourceRoot)
end
addEventHandler("onClientResourceStart", resourceRoot, requestLODsClient)

function setLODsClient(lodTbl)
	for i, model in ipairs(lodTbl) do
		engineSetModelLODDistance(model, 300)
	end
end
addEvent("setLODsClient", true)
addEventHandler("setLODsClient", resourceRoot, setLODsClient)

function applyBreakableState()
	for k, obj in pairs(getElementsByType("object", resourceRoot)) do
		local breakable = getElementData(obj, "breakable")
		if breakable then
			setObjectBreakable(obj, breakable == "true")
		end
	end
end
addEventHandler("onClientResourceStart", resourceRoot, applyBreakableState)


local txd = engineLoadTXD("b.txd")
			engineImportTXD(txd, 16349)
local dff = engineLoadDFF("c.dff",16349)
			engineReplaceModel(dff, 16349)
local col = engineLoadCOL ("c.col" )
			engineReplaceCOL ( col, 16349)

local txd = engineLoadTXD("b.txd")
			engineImportTXD(txd, 16350)
local dff = engineLoadDFF("uveg_1.dff",16350)
			engineReplaceModel(dff, 16350,true)
local col = engineLoadCOL ("uveg_1.col" )
			engineReplaceCOL ( col, 16350)

local txd = engineLoadTXD("b.txd")
			engineImportTXD(txd, 16351)
local dff = engineLoadDFF("uveg_2.dff",16351)
			engineReplaceModel(dff, 16351,true)
local col = engineLoadCOL ("uveg_2.col" )
			engineReplaceCOL ( col, 16351)

local txd = engineLoadTXD("b.txd")
			engineImportTXD(txd, 16352)
local dff = engineLoadDFF("uveg_3.dff",16352)
			engineReplaceModel(dff, 16352,true)
local col = engineLoadCOL ("uveg_3.col" )
			engineReplaceCOL ( col, 16352)

local txd = engineLoadTXD("b.txd")
			engineImportTXD(txd, 16353)
local dff = engineLoadDFF("uveg_4.dff",16353)
			engineReplaceModel(dff, 16353,true)
local col = engineLoadCOL ("uveg_4.col" )
			engineReplaceCOL ( col, 16353)


local obj = createObject(16349,1484.7998,-1806.7002,12.59990,0.0000000,0.0000000,179.995)
local obj2 = createObject(16349,1484.7998,-1806.7002,12.59990,0.0000000,0.0000000,179.995, true)
setElementStreamable ( obj, false )
engineSetModelLODDistance(16349, 500)
setLowLODElement(obj, obj2)
setElementCollisionsEnabled(obj2, false)


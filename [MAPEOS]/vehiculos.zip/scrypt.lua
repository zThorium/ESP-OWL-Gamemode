

-- start


function onResourceStart()
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), onResourceStart)

--- pojazd




txd = engineLoadTXD ( "bmwm2.txd",527 )
engineImportTXD ( txd, 527 )  

dff = engineLoadDFF ( "bmwm2.dff", 527)
engineReplaceModel ( dff, 527 )    

txd = engineLoadTXD ( "x5.txd",579 )
engineImportTXD ( txd, 579 )  

dff = engineLoadDFF ( "x5.dff", 579)
engineReplaceModel ( dff, 579 )      

txd = engineLoadTXD ( "versa.txd",445 )
engineImportTXD ( txd, 445 )  

dff = engineLoadDFF ( "versa.dff", 445)
engineReplaceModel ( dff, 445 )   

txd = engineLoadTXD ( "gtr.txd",605 )
engineImportTXD ( txd, 605 )  

dff = engineLoadDFF ( "gtr.dff", 605)
engineReplaceModel ( dff, 605 ) 








